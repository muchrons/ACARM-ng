<?php

class TimeEntryRecord
{
	public $CreatorUserName='';
	public $Category;
	public $DateCreated=0;
	public $Description='';
	public $Duration=0.0;
	public $ID=0;
	public $Project;
	public $ReportDate=0;
	public $Username;
}

?>