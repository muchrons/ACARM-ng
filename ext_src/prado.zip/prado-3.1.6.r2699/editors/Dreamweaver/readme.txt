This directory contains the Macromedia Dreamweaver Extension for PRADO.

This PRADO extension contains a tag library that enables Dreamweaver to 
auto-complete PRADO component tags when you use it to edit PRADO templates.

Before installation, make sure you have uninstalled any older versions
of the PRADO extension.

To install this extension, run Dreamweaver's extension manager program and
select the file PRADO.mxp to install. 

After installation, restart Dreamweaver. Open a new HTML document and start typing
in PRADO component tags. You will see as you are typing, a dropdown list may
pop up which contains the available component names, properties and events.
Some property types are also handled.

This extension is tested with Dreamweaver 2004 MX. Please let me know if you find it
working on other versions.

Enjoy!

Qiang
