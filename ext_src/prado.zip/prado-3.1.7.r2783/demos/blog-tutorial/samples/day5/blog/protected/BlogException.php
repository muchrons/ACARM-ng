<?php

class BlogException extends THttpException
{
}

?>