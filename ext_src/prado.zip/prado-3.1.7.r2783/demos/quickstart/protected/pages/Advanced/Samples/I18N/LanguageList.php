<?php
/**
 * Language List
 * @author $Author: weizhuo $
 * @version $Id: LanguageList.php 1398 2006-09-08 19:31:03Z xue $
 * @package prado.examples
 */

/**
 *
 * @author $Author: weizhuo $
 * @version $Id: LanguageList.php 1398 2006-09-08 19:31:03Z xue $
 */
class LanguageList extends TTemplateControl 
{
	
}

?>